package com.example.thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeleafProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymeleafProductApplication.class, args);
	}

}
