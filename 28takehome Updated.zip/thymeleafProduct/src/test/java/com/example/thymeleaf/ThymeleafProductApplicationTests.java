package com.example.thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
