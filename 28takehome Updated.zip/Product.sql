create database Product;

use Product;

create table category
(
categoryid BIGINT primary key,
categoryname VARCHAR(255)
);
create table Products
(
pid BIGINT primary key,
sku VARCHAR(255),
pname VARCHAR(255),
descriptions VARCHAR(255),
unitprice DECIMAL(13,2),
imageurl VARCHAR(255),
unitsinstock INT,
datecreated datetime,
lastupdated datetime,
categoryid BIGINT,
foreign key(categoryid) references category(categoryid)
);

select* from Products;
select * from Category;
insert into Products values(1001,"705712","Shoes","Converse",100000,"img.jpg",5,"2020-01-4 00:00:00","2020-01-11 00:00:00",10001);

insert into category values(10001,"Footwear");

ALTER TABLE Products MODIFY pid int NOT NULL AUTO_INCREMENT;